
<?php $__env->startSection("content"); ?>

<div id="carouselExampleCaptions" class="carousel slide carousel-fade mt-3" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php for($i = 0; $i < $size; $i++): ?>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo e($i); ?>" class="active" aria-current="true" aria-label="Slide <?php echo e($i); ?>"></button>
        <?php endfor; ?>
    </div>
    <div class="carousel-inner">    
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($item['id']==1?'active':''); ?>">
            <div class="overlay-image" style="background-image:url('<?php echo e($item['gallery']); ?>')"></div>
            <div class="container">
                <h4><?php echo e($item['name']); ?></h4>
                <p><?php echo e($item['description']); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\ecomm\resources\views/product.blade.php ENDPATH**/ ?>