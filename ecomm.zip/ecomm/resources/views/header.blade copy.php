<?php
use App\Http\Controllers\ProductController;
$total = 0;
if(Session::has('user'))
{
  $total = ProductController::cartItem();
}
?>
<nav class="navbar navbar-expand-lg fixed-top auto-hiding-navbar" >
  <div class="container-fluid">
    <a class="navbar-brand " href="/">
      <img src="img/allyona-logo-small-2.png" alt="Allyona logo"/>
      Allyona
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active " aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/wowphilippines">Wow Philippines!</a>
        </li>
        @if(Session::has('user'))
        <li class="nav-item "><a class="nav-link" href="/myorders">Orders</a></li>
        @endif
        <li class="nav-item">
            <a class="nav-link " href="/cartlist" >
              <!-- alt="..." on <img> element -->
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="black" class="bi bi-cart" viewBox="0 0 16 16">
                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
              </svg>
              <span class="badge bg-secondary">{{$total}}</span>
            </a>
        </li>  
        @if(Session::has('user'))
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          {{Session::get('user')['name']}}
          </a> 
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="/logout">Logout</a></li>
          </ul>
        </li>
        @else
        <li class="nav-item"><a class="nav-link " href="/login">Login</a></li>
        <li class="nav-item"><a class="nav-link " href="/register">Register</a></li>
        @endif
      </ul>
      <!-- <form action="/search" class="d-flex">
        <input class="form-control search-box me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-sm btn-outline-secondary" type="submit" style="burder: 1px solid skyblue">Search</button>
      </form> -->
    </div>
  </div>
</nav>
<div class="clear" ></div>
