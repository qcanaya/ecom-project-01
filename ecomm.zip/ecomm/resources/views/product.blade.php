@extends('master')
@section("content")

<div id="carouselExampleCaptions" class="carousel slide carousel-fade mt-3" data-bs-ride="carousel">
    <div class="carousel-indicators">
        @for ($i = 0; $i < $size; $i++)
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="{{$i}}" class="active" aria-current="true" aria-label="Slide {{$i}}"></button>
        @endfor
    </div>
    <div class="carousel-inner">    
        @foreach ($products as $item)
        <div class="carousel-item {{$item['id']==1?'active':''}}">
            <div class="overlay-image" style="background-image:url('{{$item['gallery']}}')"></div>
            <div class="container">
                <h4>{{$item['name']}}</h4>
                <p>{{$item['description']}}</p>
            </div>
        </div>
        @endforeach
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
    
@endsection