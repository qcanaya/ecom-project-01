<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([
            [
                'name'=>'MEN\'S PERFUME ETERNITY FOR MEN CALVIN KLEIN EDP',            
                'price'=>'23.93',
                'category'=>'PERFUMES',
                'description'=>'100% original Men\'s Perfume Eternity For Men Calvin Klein EDP and a broad range of Calvin Klein products',
                'gallery'=>'https://www.bigbuy.net/805681-product_card_zoom/men-s-perfume-eternity-for-men-calvin-klein-edp_248319.jpg'
            ],
            [
                'name'=>'MEN\'S PERFUME ETERNITY CALVIN KLEIN EDT',            
                'price'=>'23.93',
                'category'=>'PERFUMES',
                'description'=>'100% original Men\'s Perfume Eternity For Men Calvin Klein EDT and a broad range of Calvin Klein products',
                'gallery'=>'https://www.bigbuy.net/252157-product_card/men-s-perfume-eternity-calvin-klein-edt_47155.jpg'
            ],
            [
                'name'=>'MEN\'S PERFUME ETERNITY FOR MEN AIR CALVIN KLEIN EDT',            
                'price'=>'23.93',
                'category'=>'PERFUMES',
                'description'=>'100% original Men\'s Perfume Eternity for Men Air Calvin Klein EDT and a broad range of Calvin Klein products',
                'gallery'=>'https://www.bigbuy.net/250985-product_card/men-s-perfume-eternity-for-men-air-calvin-klein-edt_71956.jpg'
            ],
            [
                'name'=>'MEN\'S PERFUME BOGART STORY RED JACQUES BOGART EDT (100 ML)',            
                'price'=>'23.93',
                'category'=>'PERFUMES',
                'description'=>'100% original Men\'s Perfume Bogart Story Red Jacques Bogart EDT (100 ml) and a broad range of Jacques Bogart products.',
                'gallery'=>'https://www.bigbuy.net/254220-product_card_zoom/men-s-perfume-bogart-story-red-jacques-bogart-edt-100-ml_47556.jpg'
            ],
            [
                'name'=>'MEN\'S PERFUME SILVER SCENT JACQUES BOGART EDT',            
                'price'=>'23.93',
                'category'=>'PERFUMES',
                'description'=>'100% original Men\'s Perfume Silver Scent Jacques Bogart EDT and a broad range of Jacques Bogart products.',
                'gallery'=>'https://www.bigbuy.net/254217-product_card_zoom/men-s-perfume-silver-scent-jacques-bogart-edt_47555.jpg'
            ]
        ]);
    }
}
