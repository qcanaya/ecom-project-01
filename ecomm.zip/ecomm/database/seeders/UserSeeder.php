<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert([
            [
                'name'=>'Rey Allapitan',
                'email'=>'iamfreeinmymaker0522@gmail.com',
                'password'=>Hash::make('12345'),
                'referal_code'=>Hash::make('REY001'),
                'referor_code'=>Hash::make('JUN001')
            ],
            [
                'name'=>'Ed Yaona',
                'email'=>'edyaona@gmail.com',
                'password'=>Hash::make('12345'),
                'referal_code'=>'ED001',
                'referor_code'=>'REY001'
            ],
            [
                'name'=>'jhun canaya',
                'email'=>'quintincanaya@gmail.com',
                'password'=>Hash::make('12345'),
                'referal_code'=>'JUN001',
                'referor_code'=>'ED001'
            ]
            [
                'name'=>'jhun canaya',
                'email'=>'quintincanaya@gmail.com',
                'password'=>Hash::make('12345'),
                'referal_code'=>'JUN001',
                'referor_code'=>'ED001'
            ]
        ]);
    }
}
